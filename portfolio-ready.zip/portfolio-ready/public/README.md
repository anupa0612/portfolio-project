# Public Folder

Place your static assets here:
- Images (your photos, project screenshots)
- Resume PDF
- Favicon
- Any other static files

Example:
- `public/resume.pdf`
- `public/images/profile.jpg`
- `public/images/project1.png`

These files will be accessible at the root of your deployed site.
