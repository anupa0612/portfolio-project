# 📤 How to Upload This Folder to GitHub

## Method 1: Using GitHub Desktop (Easiest)

### Step 1: Install GitHub Desktop
1. Download from: https://desktop.github.com/
2. Install and sign in with your GitHub account
   - Don't have GitHub? Sign up at https://github.com/signup

### Step 2: Create Repository
1. Open GitHub Desktop
2. Click **File** → **New Repository**
3. Name: `portfolio`
4. Local Path: Choose where this folder is located
5. Click **Create Repository**

### Step 3: Publish to GitHub
1. Click **Publish repository** button
2. Uncheck "Keep this code private" (for free hosting)
3. Click **Publish repository**

### Step 4: Your folder is now on GitHub! ✅

---

## Method 2: Using Git Command Line

### Step 1: Install Git
- Download from: https://git-scm.com/downloads

### Step 2: Open Terminal/Command Prompt in this folder

### Step 3: Run these commands:

```bash
# Initialize git
git init

# Add all files
git add .

# Commit files
git commit -m "Initial commit"

# Create repository on GitHub first (https://github.com/new)
# Then connect it (replace YOUR_USERNAME and YOUR_REPO):
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git

# Push to GitHub
git branch -M main
git push -u origin main
```

---

## Method 3: Drag and Drop (GitHub Website)

### Step 1: Create New Repository
1. Go to https://github.com/new
2. Name: `portfolio`
3. Click **Create repository**

### Step 2: Upload Files
1. Click **uploading an existing file**
2. Drag and drop ALL files from this folder
3. Click **Commit changes**

**Important:** Upload ALL files including:
- `.gitignore`
- All `.js`, `.jsx`, `.json` files
- `index.html`
- `src` folder (all contents)
- Everything except `node_modules` folder (don't upload this)

---

## ✅ After Uploading to GitHub

Your repository should contain:
```
portfolio/
├── .gitignore
├── README.md
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── vercel.json
├── index.html
├── src/
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
└── public/
```

---

## 🚀 Next: Deploy to Vercel

1. Go to https://vercel.com
2. Sign in with GitHub
3. Click **New Project**
4. Select your `portfolio` repository
5. Click **Deploy**
6. Wait 2 minutes
7. Your site is live! 🎉

Your URL will be: `https://portfolio-yourusername.vercel.app`

---

## 🆘 Need Help?

**"I don't have GitHub account"**
→ Sign up free at https://github.com/signup

**"GitHub Desktop not working"**
→ Use Method 3 (drag and drop on GitHub website)

**"Upload failed"**
→ Make sure you're NOT uploading the `node_modules` folder
→ It's listed in `.gitignore` so it should be excluded automatically

**"Vercel showing 404 error"**
→ Check that `vercel.json` file was uploaded
→ Wait 2-3 minutes after deployment
→ Try redeploying in Vercel dashboard

---

Good luck! 🚀
